package com.example.apiarchitecture.model

class ReqModelContacts {
}