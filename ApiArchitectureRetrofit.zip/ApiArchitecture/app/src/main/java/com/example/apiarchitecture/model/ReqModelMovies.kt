package com.example.apiarchitecture.model

class ReqModelMovies : BaseModel(){
}