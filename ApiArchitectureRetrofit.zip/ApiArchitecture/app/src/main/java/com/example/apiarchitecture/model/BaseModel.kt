package com.example.apiarchitecture.model

import java.io.Serializable

open class BaseModel : Serializable {
}